# Roulette Game

This project is a simple roulette game implemented using HTML, CSS, and JavaScript. It features a spinning roulette wheel and a ball that bounces around according to the laws of physics.

## Project Structure

```
roleta-jogo
├── src
│   ├── index.html       # Main HTML document for the roulette game
│   ├── style.css        # Styles for the roulette game
│   └── main.js          # JavaScript code for game logic
└── README.md            # Project documentation
```

## Features

- Interactive roulette wheel that spins and stops randomly.
- A ball that simulates realistic physics as it bounces around the wheel.
- Responsive design that works on various screen sizes.

## Getting Started

To run the roulette game locally, follow these steps:

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/roleta-jogo.git
   ```

2. Navigate to the project directory:
   ```
   cd roleta-jogo
   ```

3. Open the `src/index.html` file in your web browser.

## Technologies Used

- HTML5 for the structure of the game.
- CSS3 for styling and animations.
- JavaScript for game logic and interactivity.
- Canvas API for rendering graphics.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.