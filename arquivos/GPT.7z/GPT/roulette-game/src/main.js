const canvas = document.getElementById('rouletteCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 600;
canvas.height = 600;

const wheelRadius = 250;
const ballRadius = 10;
let angle = 0;
let speed = 0.1;
let ballAngle = 0;
let ballSpeed = 0.2;
let isSpinning = false;

function drawWheel() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(angle);

    for (let i = 0; i < 36; i++) {
        ctx.beginPath();
        ctx.arc(0, -wheelRadius, wheelRadius, (i * Math.PI) / 18, ((i + 1) * Math.PI) / 18);
        ctx.lineTo(0, 0);
        ctx.fillStyle = i % 2 === 0 ? 'red' : 'black';
        ctx.fill();
        ctx.stroke();
    }

    ctx.restore();
}

function drawBall() {
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(ballAngle);
    ctx.beginPath();
    ctx.arc(0, -wheelRadius - ballRadius, ballRadius, 0, Math.PI * 2);
    ctx.fillStyle = 'white';
    ctx.fill();
    ctx.restore();
}

function update() {
    if (isSpinning) {
        angle += speed;
        ballAngle += ballSpeed;

        // Simulate ball slowing down
        ballSpeed *= 0.99;

        // Stop spinning when the ball is slow enough
        if (ballSpeed < 0.01) {
            isSpinning = false;
            ballSpeed = 0.2; // Reset ball speed for next spin
        }
    }

    drawWheel();
    drawBall();
    requestAnimationFrame(update);
}

function startSpin() {
    isSpinning = true;
}

document.addEventListener('click', startSpin);
update();