const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Variáveis do Jogo
let frame = 0;
let score = 0;
let gameState = {
    current: 0,
    getReady: 0,
    game: 1,
    over: 2
};

// Constantes
const GRAVITY = 0.25;
const LIFT = -4.6;
const PIPE_GAP = 100;
const PIPE_SPEED = 2;

// Áudio (opcional, descomente se quiser adicionar sons)
// const FLAP_SOUND = new Audio();
// FLAP_SOUND.src = "audio/flap.wav";
// const SCORE_SOUND = new Audio();
// SCORE_SOUND.src = "audio/score.wav";

// Controle do Jogo
document.addEventListener('click', function(evt) {
    switch (gameState.current) {
        case gameState.getReady:
            gameState.current = gameState.game;
            break;
        case gameState.game:
            player.flap();
            // FLAP_SOUND.play();
            break;
        case gameState.over:
            resetGame();
            break;
    }
});

document.addEventListener('keydown', function(evt) {
    if (evt.code === "Space") {
        switch (gameState.current) {
            case gameState.getReady:
                gameState.current = gameState.game;
                break;
            case gameState.game:
                player.flap();
                // FLAP_SOUND.play();
                break;
            case gameState.over:
                resetGame();
                break;
        }
    }
});


// Objeto do Personagem (Player)
const player = {
    x: 50,
    y: 150,
    width: 34,
    height: 24,
    speed: 0,

    draw: function() {
        ctx.fillStyle = "#FFD700"; // Cor amarela para o nosso "herói"
        ctx.fillRect(this.x, this.y, this.width, this.height);
    },

    flap: function() {
        this.speed = LIFT;
    },

    update: function() {
        // Se o estado é 'getReady', o personagem bate as asas lentamente
        if (gameState.current === gameState.getReady) {
            this.y = 150; // Posição inicial
        } else {
            this.speed += GRAVITY;
            this.y += this.speed;

            // Detecção de colisão com o chão
            if (this.y + this.height >= canvas.height) {
                this.y = canvas.height - this.height;
                if (gameState.current === gameState.game) {
                    gameState.current = gameState.over;
                }
            }
            // Detecção de colisão com o teto
            if (this.y <= 0) {
                this.y = 0;
                this.speed = 0;
            }
        }
    }
};

// Objeto dos Canos (Pipes)
const pipes = {
    position: [],
    width: 52,
    gap: PIPE_GAP,
    maxYPos: -150,

    draw: function() {
        for (let i = 0; i < this.position.length; i++) {
            let p = this.position[i];
            let bottomPipeTopY = p.y + p.height + this.gap;

            // Cano de cima
            ctx.fillStyle = "#2E8B57"; // Verde
            ctx.fillRect(p.x, p.y, this.width, p.height);
            // Cano de baixo
            ctx.fillRect(p.x, bottomPipeTopY, this.width, p.height);
        }
    },

    update: function() {
        if (gameState.current !== gameState.game) return;

        // Adiciona um novo cano a cada 100 frames
        if (frame % 100 === 0) {
            this.position.push({
                x: canvas.width,
                y: this.maxYPos * (Math.random() + 1),
                height: 400 // Altura fixa para os canos
            });
        }

        for (let i = 0; i < this.position.length; i++) {
            let p = this.position[i];
            p.x -= PIPE_SPEED;

            // Detecção de colisão
            let bottomPipeYPos = p.y + p.height + this.gap;
            if (player.x + player.width > p.x && player.x < p.x + this.width &&
                (player.y < p.y + p.height || player.y + player.height > bottomPipeYPos)) {
                gameState.current = gameState.over;
            }

            // Aumenta a pontuação
            if (p.x + this.width < player.x && !p.passed) {
                score++;
                // SCORE_SOUND.play();
                p.passed = true;
            }

            // Remove os canos que saíram da tela
            if (p.x + this.width < 0) {
                this.position.shift();
            }
        }
    },

    reset: function() {
        this.position = [];
    }
};

// Mensagens do Jogo
function drawText(text, x, y, color = "white", size = "30px") {
    ctx.fillStyle = color;
    ctx.font = `${size} Arial`;
    ctx.textAlign = "center";
    ctx.fillText(text, x, y);
}

// Função para desenhar tudo na tela
function draw() {
    // Fundo
    ctx.fillStyle = "#70c5ce";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Desenha os canos e o personagem
    pipes.draw();
    player.draw();

    // Desenha a pontuação
    if (gameState.current === gameState.game) {
        drawText(score, canvas.width / 2, 50);
    }

    // Tela inicial
    if (gameState.current === gameState.getReady) {
        drawText("Clique para Começar", canvas.width / 2, canvas.height / 2 - 50);
    }

    // Tela de Game Over
    if (gameState.current === gameState.over) {
        drawText("Fim de Jogo", canvas.width / 2, canvas.height / 2 - 50);
        drawText(`Pontuação: ${score}`, canvas.width / 2, canvas.height / 2);
        drawText("Clique para reiniciar", canvas.width / 2, canvas.height / 2 + 50, "white", "20px");
    }
}

// Função de atualização do jogo
function update() {
    player.update();
    pipes.update();
}

// Loop principal do jogo
function loop() {
    update();
    draw();
    frame++;
    requestAnimationFrame(loop);
}

// Função para reiniciar o jogo
function resetGame() {
    player.speed = 0;
    player.y = 150;
    pipes.reset();
    score = 0;
    gameState.current = gameState.getReady;
}

// Inicia o jogo
resetGame();
loop();
