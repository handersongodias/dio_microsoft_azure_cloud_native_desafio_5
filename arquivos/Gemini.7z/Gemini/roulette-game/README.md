# Roulette Game

## Overview
This project is a simple roulette game that simulates the spinning of a roulette wheel with a ball bouncing in the center. The game is built using HTML, CSS, and JavaScript, utilizing the HTML canvas for rendering graphics and animations.

## Project Structure
```
roulette-game
├── src
│   ├── index.html       # Main HTML document for the roulette game
│   ├── styles.css       # Styles for the roulette game
│   └── main.js          # JavaScript code for game logic
├── README.md            # Project documentation
```

## Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, etc.)
- Basic understanding of HTML, CSS, and JavaScript

### Running the Game
1. Clone the repository or download the project files.
2. Open the `src/index.html` file in your web browser.
3. Enjoy the game!

## Game Mechanics
- The roulette wheel spins at a constant speed.
- A ball is animated to bounce in the center of the wheel, simulating realistic physics.
- The game follows the laws of physics on Earth, providing an engaging experience.

## Contributing
Feel free to fork the repository and submit pull requests for any improvements or features you'd like to add!

## License
This project is open-source and available under the MIT License.