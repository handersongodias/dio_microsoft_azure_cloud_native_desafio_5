// This file contains the JavaScript code that implements the game logic for the roulette game.

const canvas = document.getElementById('rouletteCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 600;
canvas.height = 600;

const wheelRadius = 250;
const ballRadius = 10;
const spinButton = document.getElementById('spinButton');

let spinning = false;
let angle = 0;
let speed = 0;
let ballAngle = 0;
let ballSpeed = 0;
let animationId = null;

function drawWheel() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(angle);

    // Draw the roulette wheel
    ctx.fillStyle = '#ff0000';
    ctx.beginPath();
    ctx.arc(0, 0, wheelRadius, 0, Math.PI * 2);
    ctx.fill();

    // Draw the ball
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    // Ball always stays on the edge, even when stopped
    let r = wheelRadius - 30;
    ctx.arc(r * Math.cos(ballAngle), r * Math.sin(ballAngle), ballRadius, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
}

function update() {
    if (spinning) {
        angle += speed;
        speed *= 0.985; // friction
        ballAngle -= ballSpeed;
        ballSpeed *= 0.985;
        if (speed < 0.005) {
            spinning = false;
            speed = 0;
            ballSpeed = 0;
        }
    }
    drawWheel();
    animationId = requestAnimationFrame(update);
}

function startSpin() {
    if (spinning) return;
    spinning = true;
    speed = 0.25 + Math.random() * 0.25; // random initial speed
    ballSpeed = 0.35 + Math.random() * 0.15;
    ballAngle = Math.random() * Math.PI * 2;
}

spinButton.addEventListener('click', startSpin);

// Start animation loop (wheel and ball only move when spinning)
update();