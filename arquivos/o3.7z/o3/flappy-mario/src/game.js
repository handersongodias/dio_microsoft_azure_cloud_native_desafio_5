const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const marioImage = new Image();
marioImage.src = 'src/mario.png'; // ajuste o caminho conforme necessário

let mario = {
    x: 0, // começa no canto esquerdo
    y: canvas.height / 2 - 20, // centralizado verticalmente (ajustado pelo height/2)
    width: 40,
    height: 40,
    gravity: 0.6,
    lift: -13, // salto mais suave
    velocity: 0,
    jump: function() {
        this.velocity += this.lift;
    },
    update: function() {
        this.velocity += this.gravity;
        this.y += this.velocity;

        if (this.y + this.height >= canvas.height) {
            this.y = canvas.height - this.height;
            this.velocity = 0;
        }

        if (this.y < 0) {
            this.y = 0;
            this.velocity = 0;
        }
    },
    draw: function() {
        if (marioImage.complete && marioImage.naturalWidth !== 0) {
            ctx.drawImage(marioImage, this.x, this.y, this.width, this.height);
        } else {
            // Fallback: desenha um retângulo se a imagem não carregar
            ctx.fillStyle = 'red';
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }
};

// Obstáculos (canos)
const pipeWidth = 60;
const pipeGap = 150;
let pipes = [];

function createPipe() {
    const minHeight = 50;
    const maxHeight = canvas.height - pipeGap - 110;
    const topHeight = Math.floor(Math.random() * (maxHeight - minHeight + 1)) + minHeight;
    return {
        x: canvas.width,
        width: pipeWidth,
        top: topHeight,
        bottom: canvas.height - topHeight - pipeGap - 60 // 60 = chão
    };
}

function resetPipes() {
    pipes = [];
    pipes.push(createPipe());
}

function updatePipes() {
    for (let i = 0; i < pipes.length; i++) {
        pipes[i].x -= 2;
    }
    // Remove canos fora da tela e adiciona novos
    if (pipes.length && pipes[0].x + pipeWidth < 0) {
        pipes.shift();
    }
    if (pipes.length === 0 || pipes[pipes.length - 1].x < canvas.width - 200) {
        pipes.push(createPipe());
    }
}

function drawPipes() {
    ctx.fillStyle = '#228B22';
    for (let pipe of pipes) {
        // Cano superior
        ctx.fillRect(pipe.x, 0, pipe.width, pipe.top);
        // Cano inferior
        const bottomPipeY = pipe.top + pipeGap;
        ctx.fillRect(pipe.x, bottomPipeY, pipe.width, canvas.height - bottomPipeY - 60);
    }
}

function checkCollision() {
    for (let pipe of pipes) {
        // Verifica colisão horizontal
        if (
            mario.x < pipe.x + pipe.width &&
            mario.x + mario.width > pipe.x
        ) {
            // Verifica colisão vertical com o topo ou base do cano
            if (
                mario.y < pipe.top ||
                mario.y + mario.height > canvas.height - pipe.bottom - 60
            ) {
                return true;
            }
        }
    }
    return false;
}

function drawBackground() {
    // Céu
    ctx.fillStyle = '#87CEEB';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Chão
    ctx.fillStyle = '#228B22';
    ctx.fillRect(0, canvas.height - 60, canvas.width, 60);
}

let gameStarted = false;

function startGame() {
    document.addEventListener('keydown', function(event) {
        if (event.code === 'Space') {
            mario.jump();
        }
    });

    resetPipes();

    function gameLoop() {
        drawBackground();
        updatePipes();
        drawPipes();
        mario.update();
        mario.draw();

        if (checkCollision()) {
            // Reinicia o jogo ao colidir
            resetPipes();
            mario.y = canvas.height / 2 - 20;
            mario.velocity = 0;
        }

        requestAnimationFrame(gameLoop);
    }

    gameLoop();
}

window.onload = function() {
    startGame();
};