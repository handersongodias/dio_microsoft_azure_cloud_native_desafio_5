# Flappy Mario

Flappy Mario is a simple web-based game inspired by the classic Flappy Bird, featuring Mario as the main character. The objective of the game is to navigate Mario through a series of pipes without colliding with them.

## Project Structure

```
flappy-mario
├── index.html        # Main HTML document
├── src
│   ├── game.js       # JavaScript code for the game
│   └── mario.png     # Image asset for Mario
├── styles
│   └── style.css     # CSS styles for the game
└── README.md         # Project documentation
```

## How to Play

1. Open `index.html` in your web browser.
2. Press the spacebar or click the mouse to make Mario jump.
3. Navigate through the pipes without hitting them to score points.
4. The game ends if Mario collides with a pipe.

## Setup Requirements

- A modern web browser (Chrome, Firefox, Safari, etc.)
- No additional setup is required; simply open the `index.html` file to start playing.

## Controls

- **Jump**: Press the spacebar or click the mouse to make Mario jump.

Enjoy playing Flappy Mario!